// /lib/daemon/command.c
// Command Daemon - Routes and executes all player commands

#include <globals.h>

inherit DAEMON;

// Global command registry
private mapping commands;
private mapping aliases;
private string *command_paths;

void create() {
    ::create();
    
    commands = ([]);
    aliases = ([]);
    
    // Define command search paths (in priority order)
    command_paths = ({
        "/cmds/",
        "/cmds/admin/",
    });
    
    // Initialize command registry
    init_commands();
}

void init_commands() {
    // Movement commands
    commands["north"] = "/cmds/go";
    commands["south"] = "/cmds/go";
    commands["east"] = "/cmds/go";
    commands["west"] = "/cmds/go";
    commands["up"] = "/cmds/go";
    commands["down"] = "/cmds/go";
    commands["n"] = "/cmds/go";
    commands["s"] = "/cmds/go";
    commands["e"] = "/cmds/go";
    commands["w"] = "/cmds/go";
    commands["u"] = "/cmds/go";
    commands["d"] = "/cmds/go";
    
    // Communication
    commands["say"] = "/cmds/say";
    commands["'"] = "/cmds/say";
    commands["tell"] = "/cmds/tell";
    commands["shout"] = "/cmds/shout";
    commands["emote"] = "/cmds/emote";
    commands[":"] = "/cmds/emote";
    
    // Information
    commands["look"] = "/cmds/look";
    commands["l"] = "/cmds/look";
    commands["examine"] = "/cmds/examine";
    commands["inventory"] = "/cmds/inventory";
    commands["i"] = "/cmds/inventory";
    commands["stats"] = "/cmds/stats";
    commands["score"] = "/cmds/score";
    commands["who"] = "/cmds/who";
    commands["help"] = "/cmds/help";
    
    // Actions
    commands["get"] = "/cmds/get";
    commands["drop"] = "/cmds/drop";
    commands["give"] = "/cmds/give";
    commands["use"] = "/cmds/use";
    
    // Character development
    commands["skills"] = "/cmds/skills";
    commands["languages"] = "/cmds/languages";
    commands["cast"] = "/cmds/cast";
    
    // System
    commands["quit"] = "/cmds/quit";
    commands["logout"] = "/cmds/quit";
    
    // Admin commands (will check privilege)
    commands["shutdown"] = "/cmds/admin/shutdown";
    commands["promote"] = "/cmds/admin/promote";
    commands["users"] = "/cmds/admin/users";
}

// Main command execution function
int execute_command(object player, string input) {
    string verb, args;
    object room, wiztool;
    int result;
    
    if (!player || !input || input == "") {
        return 0;
    }
    
    // Parse command into verb and arguments
    if (sscanf(input, "%s %s", verb, args) != 2) {
        verb = input;
        args = "";
    }
    
    verb = lower_case(verb);
    
    // Priority 1: Check wiztool (for wizards/admins)
    wiztool = player->query_wiztool();
    if (wiztool) {
        result = wiztool->process_command(verb, args);
        if (result) return 1;
    }
    
    // Priority 2: Check player's local commands (skills, abilities)
    if (function_exists("local_command", player)) {
        result = player->local_command(verb, args);
        if (result) return 1;
    }
    
    // Priority 3: Check environment commands (room-specific)
    room = environment(player);
    if (room && function_exists("local_command", room)) {
        result = room->local_command(verb, args);
        if (result) return 1;
    }
    
    // Priority 4: Check global command registry
    if (commands[verb]) {
        return execute_global_command(player, commands[verb], verb, args);
    }
    
    // Priority 5: Try to find command in search paths
    result = search_command_paths(player, verb, args);
    if (result) return 1;
    
    // Command not found
    tell_object(player, "Unknown command: " + verb);
    tell_object(player, "Type 'help' for available commands.");
    return 0;
}

// Execute a registered global command
private int execute_global_command(object player, string path, string verb, string args) {
    object cmd;
    int result;
    
    // Try to load the command object
    catch {
        cmd = load_object(path);
    };
    
    if (!cmd) {
        tell_object(player, "Error: Command '" + verb + "' failed to load.");
        return 0;
    }
    
    // Check if command has privilege requirements
    if (function_exists("query_privilege_required", cmd)) {
        int required = cmd->query_privilege_required();
        int player_priv = player->query_privilege();
        
        if (player_priv < required) {
            tell_object(player, "You don't have sufficient privileges for that command.");
            return 0;
        }
    }
    
    // Execute the command
    if (function_exists("main", cmd)) {
        result = cmd->main(player, args);
        return result;
    }
    
    tell_object(player, "Error: Command '" + verb + "' is not properly implemented.");
    return 0;
}

// Search command paths for a matching command file
private int search_command_paths(object player, string verb, string args) {
    string path;
    object cmd;
    
    foreach (string dir in command_paths) {
        path = dir + verb;
        
        catch {
            cmd = load_object(path);
        };
        
        if (cmd && function_exists("main", cmd)) {
            return execute_global_command(player, path, verb, args);
        }
    }
    
    return 0;
}

// Register a new command
void register_command(string verb, string path) {
    commands[verb] = path;
}

// Unregister a command
void unregister_command(string verb) {
    map_delete(commands, verb);
}

// Get list of available commands
string *query_commands() {
    return keys(commands);
}

// Get command mapping (for debugging)
mapping query_command_map() {
    return copy(commands);
}
