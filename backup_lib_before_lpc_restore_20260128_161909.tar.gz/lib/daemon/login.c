// /lib/daemon/login.c
// Login Daemon - Handles login coordination

inherit "/std/daemon";

void create() {
    ::create();
}

// Daemon stub - functionality in /clone/login.c
