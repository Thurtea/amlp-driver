// /lib/races/.lpc
//  Race - Placeholder Implementation
//
// This is a stub file. Implement the full race details.

inherit "/std/race";

void create() {
    ::create();
    
    set_race_name("");
    set_race_id("noli");
    set_race_plural("s");
    set_race_category(RACE_CAT_DEMIHUMAN);
    
    set_race_description(
        "TODO: Add full race description for ."
    );
    
    // TODO: Configure physical characteristics
    set_size_category(SIZE_MEDIUM);
    set_height_range(60, 72);
    set_weight_range(120, 200);
    set_lifespan(80);
    
    // TODO: Configure stat modifiers
    set_stat_modifiers(([
        // Example: "ps": 2
    ]));
    
    // TODO: Configure racial abilities
    set_racial_abilities(({ }));
    
    // TODO: Configure OCC restrictions
    set_allowed_occs(({ }));
    set_forbidden_occs(({ }));
    set_recommended_occs(({ }));
    
    // TODO: Configure starting resources
    set_starting_equipment(({ }));
    set_starting_credits(100);
    
    set_languages(({ "american" }));
    set_primary_language("american");
}
