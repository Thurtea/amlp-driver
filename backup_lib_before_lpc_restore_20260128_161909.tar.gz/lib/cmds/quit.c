// Quit command

#include <globals.h>

int main(string arg) {
    object user;
    
    user = previous_object();
    tell_object(user, "Goodbye.\n");
    user->remove();
    return 1;
}
